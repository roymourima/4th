#1. Opens and reads a text file named sample.txt.


ph = open("sample.txt", "rt")

Line1 = ph.readline()
Line2 = ph.readline()
ph.close()
print("Reading File Content:")
print(f"Line1: {Line1}")
print(f"Line2: {Line2}")




#2. Function to handle all operations
def file_handling_program():


    # Takes user input and writes it to a file named output.txt.
    initial_text = input("Enter text to write to the file: ")
    with open("output.txt", "w") as file:
        file.write(initial_text + "\n")
    print("Data successfully written to output.txt.")

    # Appends additional data to the same file.
    additional_text = input("Enter additional text to append: ")
    with open("output.txt", "a") as file:
        file.write(additional_text + "\n")
    print("Data successfully appended.")

    # Reads and displays the final content of the file line by line.
    print("\nFinal content of output.txt:")
    with open("output.txt", "r") as file:
        for line in file:
            print(line, end="")

# Run the program
file_handling_program()

